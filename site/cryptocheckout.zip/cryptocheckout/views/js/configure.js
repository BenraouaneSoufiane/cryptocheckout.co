window?.psaccountsVue?.init();

let billingContext = { ...window.psBillingContext.context }
let currentModal;
let customer;

if (window.psaccountsVue.isOnboardingCompleted() == true) {

    showPlanSelection();

    customer = new window.psBilling.CustomerComponent({
        context: billingContext,
        hideInvoiceList: true,
        onOpenModal,
        onEventHook
    });
    customer.render('#ps-billing');
}

// Modal open / close management
async function onCloseModal(data) {
    await Promise.all([currentModal.close(), updateCustomerProps(data)]);
};

function onOpenModal(type, data) {
    currentModal = new window.psBilling.ModalContainerComponent({
        type,
        context: {
            ...billingContext,
            ...data,
        },
        onCloseModal,
        onEventHook
    });
    currentModal.render('#ps-modal');
};

function updateCustomerProps(data) {
    return customer.updateProps({
        context: {
            ...billingContext,
            ...data,
        },
    });
};

// Event hook management
function onEventHook(type, data) {
    // Event hook listener
    switch (type) {
        case window.psBilling.EVENT_HOOK_TYPE.SUBSCRIPTION_CREATED:
            showBillingWrapper();
            break;
        case window.psBilling.EVENT_HOOK_TYPE.SUBSCRIPTION_UPDATED:
            showBillingWrapper();
            break;
    }
}

function showPlanSelection() {
    document.getElementById('billing-plan-selection').style.display = 'block';
    document.getElementById('ps-billing-wrapper').style.display = 'none';
}

function showBillingWrapper() {
    document.getElementById('billing-plan-selection').style.display = 'none';
    document.getElementById('ps-billing-wrapper').style.display = 'block';
}

// Open the checkout full screen modal
function openCheckout() {
  /*  const offerSelection = { selectedPlan: JSON.parse(plan)};
   onOpenModal(window.psBilling.MODAL_TYPE.SUBSCRIPTION_FUNNEL, offerSelection);
   console.log(plan)*/
   
        
    const offerSelection = { selectedPlan: plan};
   onOpenModal(window.psBilling.MODAL_TYPE.SUBSCRIPTION_FUNNEL, offerSelection);
};