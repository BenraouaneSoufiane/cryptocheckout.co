<?php
/**
* 2007-2024 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2024 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

$autoloadPath = __DIR__ . '/vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}
use PrestaShop\PrestaShop\Core\Addon\Module\ModuleManagerBuilder;
class Cryptocheckout extends PaymentModule
{
    protected $config_form = false;
    private $container;
    public $crypto_currencies = array('USDT','BTC','ETH','SOL','DOT','AVAX','ADA','XTZ','XMR');
    public $useLightMode;


    public function __construct()
    {
        $this->name = 'cryptocheckout';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'CryptoCheckout';
        $this->need_instance = 0;
        $this->useLightMode = true;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('CryptoCheckout');
        $this->description = $this->l('Secure simple decentralized crypto payment processor');

        $this->limited_countries = array('FR');

        $this->limited_currencies = array('EUR');

        $this->ps_versions_compliancy = array('min' => '1.7.8', 'max' => '8.1.6');
        if ($this->container === null) {
            $this->container = new \PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer(
                $this->name,
                $this->getLocalPath()
            );
        }
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        
            //$this->getService('ps_accounts.installer')->install();

          /* CloudSync */
        $moduleManager = ModuleManagerBuilder::getInstance()->build();

        if (!$moduleManager->isInstalled("ps_eventbus")) {
            $moduleManager->install("ps_eventbus");
        } else if (!$moduleManager->isEnabled("ps_eventbus")) {
            $moduleManager->enable("ps_eventbus");
            $moduleManager->upgrade('ps_eventbus');
        } else {
            $moduleManager->upgrade('ps_eventbus');
        }
        if (extension_loaded('curl') == false)
        {
            $this->_errors[] = $this->l('You have to enable the cURL extension on your server to install this module');
            return false;
        }

        $iso_code = Country::getIsoById(Configuration::get('PS_COUNTRY_DEFAULT'));

        /*if (in_array($iso_code, $this->limited_countries) == false)
        {
            $this->_errors[] = $this->l('This module is not available in your country');
            return false;
        }*/

        Configuration::updateValue('CRYPTOCHECKOUT_LIVE_MODE', true);
        foreach($this->crypto_currencies as $currency){
            Configuration::updateValue('CRYPTOCHECKOUT_ENABLE_'.$currency,1);
        }

        return parent::install() &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('payment') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('paymentOptions') && 
            $this->getService('cryptocheckout.ps_accounts_installer')->install();

    }

    public function uninstall()
    {
        Configuration::deleteByName('CRYPTOCHECKOUT_LIVE_MODE');
        foreach($this->crypto_currencies as $currency){
            Configuration::deleteByName('CRYPTOCHECKOUT_ENABLE_'.$currency);
            Configuration::deleteByName('CRYPTOCHECKOUT_'.$currency.'_ADDRESS');
            Configuration::deleteByName('CRYPTOCHECKOUT_'.$currency.'_PRICE');
            Configuration::deleteByName('CRYPTOCHECKOUT_SUBSCRIPTION_ID');
            Configuration::deleteByName('CRYPTOCHECKOUT_SUBSCRIPTION_END');
        }
        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitCryptocheckoutModule')) == true) {
            $this->postProcess();
        }
        
        $moduleManager = ModuleManagerBuilder::getInstance()->build();


        $this->context->smarty->assign('module_dir', $this->_path);
        /*********************
        * PrestaShop Account *
        * *******************/

        $accountsService = null;

        try {
            $accountsFacade = $this->getService('cryptocheckout.ps_accounts_facade');
            $accountsService = $accountsFacade->getPsAccountsService();
        } catch (\PrestaShop\PsAccountsInstaller\Installer\Exception\InstallerException $e) {
            $accountsInstaller = $this->getService('cryptocheckout.ps_accounts_installer');
            $accountsInstaller->install();
            $accountsFacade = $this->getService('cryptocheckout.ps_accounts_facade');
            $accountsService = $accountsFacade->getPsAccountsService();
        }

        try {
            Media::addJsDef([
                'contextPsAccounts' => $accountsFacade->getPsAccountsPresenter()
                    ->present($this->name),
            ]);

            // Retrieve the PrestaShop Account CDN
            $this->context->smarty->assign(
                
                    'urlAccountsCdn',$accountsService->getAccountsCdn()
                
            );
            

        } catch (Exception $e) {
            $this->context->controller->errors[] = $e->getMessage();
            return '';
        }
       

        /**********************
         * PrestaShop Billing *
         * *******************/

        // Load the context for PrestaShop Billing
        $billingFacade = $this->getService('cryptocheckout.ps_billings_facade');
        $partnerLogo = $this->getLocalPath() . 'logo.png';

        // PrestaShop Billing
        Media::addJsDef($billingFacade->present([
          'logo' => $partnerLogo,
          'tosLink' => 'https://cryptocheckout.co/terms/',
          'privacyLink' => 'https://cryptocheckout.co/privacy-policy/',
          // This field is deprecated but a valid email must be provided to ensure backward compatibility
          'emailSupport' => 'support@cryptocheckout.co'
        ]));
        
        $this->context->smarty->assign('urlBilling', "https://unpkg.com/@prestashopcorp/billing-cdc/dist/bundle.js");
 // Retrieve plans and addons for your module
     
      
      
     //$this->context->smarty->assign('urlConfigureJs',$this->getPathUri() . 'views/js/configure.js');
     // Retrieve current subscription

     
     //$this->context->smarty->assign('urlConfigureJs',$this->getPathUri() . 'views/js/configure.js');
       if ($moduleManager->isInstalled("ps_eventbus")) {
          $eventbusModule =  \Module::getInstanceByName("ps_eventbus");
          if (version_compare($eventbusModule->version, '1.9.0', '>=')) {

              $eventbusPresenterService = $eventbusModule->getService('PrestaShop\Module\PsEventbus\Service\PresenterService');

              $this->context->smarty->assign('urlCloudsync', "https://assets.prestashop3.com/ext/cloudsync-merchant-sync-consent/latest/cloudsync-cdc.js");

              Media::addJsDef([
                  'contextPsEventbus' => $eventbusPresenterService->expose($this, ['info', 'modules', 'themes'])
              ]);
          }
      }

    
        $output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
        
        $currentSubscription = $this->currentSubscription();
        
        //print_r();
        //print_r(Configuration::get('CRYPTOCHECKOUT_ENABLE_USDT'));

        return $output.$this->renderForm();
    }
    public function currentSubscription(){
        $billingService = $this->getService('cryptocheckout.ps_billings_service');
        return $billingService->getCurrentSubscription();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitCryptocheckoutModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {   
        $default = array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Settings'),
                'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Live mode'),
                        'name' => 'CRYPTOCHECKOUT_LIVE_MODE',
                        'is_bool' => true,
                        'desc' => $this->l('Use this module in live mode'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),                    
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
        foreach($this->crypto_currencies as $currency){
            $default['form']['input'][] = array(
                        'type' => 'switch',
                        'label' => $this->l($currency),
                        'name' => 'CRYPTOCHECKOUT_ENABLE_'.$currency,
                        'is_bool' => true,
                        'desc' => $this->l('Accept '.$currency.' payments'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )
                        ),                                                  
                    );
            $default['form']['input'][] =  array(
                        'col' => 5,
                        'type' => 'text',
                        'desc' => $this->l('Enter a valid '.$currency.' address'),
                        'name' => 'CRYPTOCHECKOUT_'.$currency.'_ADDRESS',
                        'label' => $this->l($currency),
                    );
            $default['form']['input'][] =  array(
                        'col' => 5,
                        'type' => 'text',
                        'desc' => $this->l('Enter specific price for '.$currency.' (keep it empty for market price)'),
                        'name' => 'CRYPTOCHECKOUT_'.$currency.'_PRICE',
                        'label' => $this->l($currency.' Isolated Price'),
                    );
        }
        return $default;
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        $default = array(
            'CRYPTOCHECKOUT_LIVE_MODE' => Configuration::get('CRYPTOCHECKOUT_LIVE_MODE'),
        );
        foreach($this->crypto_currencies as $currency ){
            $default['CRYPTOCHECKOUT_ENABLE_'.$currency] = Configuration::get('CRYPTOCHECKOUT_ENABLE_'.$currency);
            $default['CRYPTOCHECKOUT_'.$currency.'_ADDRESS'] = Configuration::get('CRYPTOCHECKOUT_'.$currency.'_ADDRESS');
            $default['CRYPTOCHECKOUT_'.$currency.'_PRICE'] = Configuration::get('CRYPTOCHECKOUT_'.$currency.'_PRICE');
        }
        return $default;
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();
        $merchant_addresses = array();
        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
            if(strpos($key,'_ADDRESS')!==false){
               $merchant_addresses[strtolower(str_replace('CRYPTOCHECKOUT_','',str_replace('_ADDRESS','',$key)))]=Tools::getValue($key);
            }
        }
        $this->postAddresses($merchant_addresses);
        $currentSubscription = $this->currentSubscription();
        if($currentSubscription!=='' && $currentSubscription!==null){
            Configuration::updateValue('CRYPTOCHECKOUT_SUBSCRIPTION_ID',$currentSubscription['body']['id']);
            Configuration::updateValue('CRYPTOCHECKOUT_SUBSCRIPTION_END',$currentSubscription['body']['next_billing_at']);
        }
    }
    protected function postAddresses($merchant_addresses){
        if(Configuration::get('CRYPTOCHECKOUT_SUBSCRIPTION_ID')){
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);
            
            curl_setopt($ch, CURLOPT_URL,'https://cryptocheckout.co/back.php?as='.Configuration::get('CRYPTOCHECKOUT_SUBSCRIPTION_ID').'&type=presta');
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,
            json_encode($merchant_addresses));
            
            // In real life you should use something like:
            // curl_setopt($ch, CURLOPT_POSTFIELDS, 
            //          http_build_query(array('postvar1' => 'value1')));
            
            // Receive server response ...
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            $server_output = curl_exec($ch);
            
            curl_close($ch);
        }
        
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookDisplayHeader()
    {


        $currency = new Currency((int)$this->context->cookie->id_currency);
        $cr = $currency->conversion_rate;
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
        $at_least_one_currency_anabled = false;
        $at_least_one_address_provided = false;
        $current_time_seconds = time();
        $merchant_addresses = array();
        $crypto_prices = array();
        foreach($this->crypto_currencies as $currency){
            if(Configuration::get('CRYPTOCHECKOUT_ENABLE_'.$currency)){
                $at_least_one_currency_anabled = true;
                if(Configuration::get('CRYPTOCHECKOUT_'.$currency.'_ADDRESS') && Configuration::get('CRYPTOCHECKOUT_ENABLE_'.$currency)){                            
                    $at_least_one_address_provided = true;
                    $merchant_addresses[strtolower($currency)] = Configuration::get('CRYPTOCHECKOUT_'.$currency.'_ADDRESS');                           
                }
                if(Configuration::get('CRYPTOCHECKOUT_'.$currency.'_PRICE')){
                    $crypto_prices[strtolower($currency)] = Configuration::get('CRYPTOCHECKOUT_'.$currency.'_PRICE');                           
                }else{
                    $rate = json_decode(file_get_contents('https://rates.cryptocheckout.co/rate.php?from=USD&to='.$currency))->rate;                    
                    $crypto_prices[strtolower($currency)] = $rate;                                               
                }
            }
        }
        $this->context->controller->registerJavascript(
            'jquery',
            'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js',
            [
                'position' => 'head',
                'priority' => 1,
                'server' => 'remote',
            ]
        );
        
        
        if( Configuration::get('CRYPTOCHECKOUT_SUBSCRIPTION_END') > $current_time_seconds && $at_least_one_address_provided && $at_least_one_currency_anabled ){
            $this->context->smarty->assign([
                'address' => json_encode($merchant_addresses),
                'rates'   => json_encode($crypto_prices),
                'conversion_rate' => $cr
            ]);
            
            $this->context->controller->registerJavascript(
                'cryptocheckout',
                'https://cryptocheckout.co/crypto-presta.js?id='.Configuration::get('CRYPTOCHECKOUT_SUBSCRIPTION_ID').'&lang=en',
                [
                    'position' => 'head',
                    'priority' => 2,
                    'server' => 'remote',
                ]
            );
        }            
       
    }


    /**
     * This hook is used to display the order confirmation page.
     */
    public function hookPaymentReturn($params)
    {
        if ($this->active == false)
            return;

        $order = $params['objOrder'];

        $this->smarty->assign(array(
            'id_order' => $order->id,
            'reference' => $order->reference,
            'params' => $params,
            'total' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
            'status' => 'ok'
        ));

        return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
    }

    /**
     * Return payment options available for PS 1.7+
     *
     * @param array Hook parameters
     *
     * @return array|null
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active ) {
            return;
        }
        /*if (!$this->checkCurrency($params['cart'])) {
            return;
        }*/
        $option = new \PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $option->setCallToActionText($this->l('Pay using crypto currencies'))->setAdditionalInformation($this->generateForm())
            ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true));

        return [
            $option
        ];
    }
    protected function generateForm(){
        $at_least_one_currency_anabled = false;
        $at_least_one_address_provided = false;
        foreach($this->crypto_currencies as $currency){
            if(Configuration::get('CRYPTOCHECKOUT_ENABLE_'.$currency)){
                $at_least_one_currency_anabled = true;
                if(Configuration::get('CRYPTOCHECKOUT_'.$currency.'_ADDRESS') && Configuration::get('CRYPTOCHECKOUT_ENABLE_'.$currency)){
                    $at_least_one_address_provided = true;
                }                        
            }
        }
        if($at_least_one_currency_anabled===false){
            $this->context->smarty->assign('nothingenabled', true);
        }
        if($at_least_one_address_provided===false){
            $this->context->smarty->assign('nothingprovided', true);
        } 
        $this->context->smarty->assign([
            'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true)         
        ]);
        return $this->context->smarty->fetch($this->local_path.'views/templates/front/payment_form.tpl');                
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }
    public function getService($serviceName)
    {
        return $this->container->getService($serviceName);
    }
}
