<?php

?>
<!doctype html>
<html style="background-color:white;font-family: Arial;">
<head  >
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.png" />
	<script type="text/javascript" src="/jquery.min.js"></script>
	 <title>Crypto | Changelog</title>
</head>
<body style="background-color:white;font-family: Arial;" >
    <div id="greeting" style="position: relative;width: 55%;margin-right:auto;margin-left:auto;margin-top:80px">
        <h1 style="text-align: center">Here's to take notes on our Crypto Payment Gateway updates!</h1>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.00 20-04-2021 First release: Basic functions ( BTC & BCH only ), other crypto currencies will be added soon.</p><br/>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.10 25-04-2021. Add dynamic address, you're not obliged to each time include new address, adding payment notifications by email, adding wif import: you're not obliged to start new wallet</p><br/>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.11 10-01-2022. Update User interface</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.12 19-02-2022. Update/optimize script, update main functionality to enhance security (adding validation by time in backend, return/move 6 charcter of user's address to first step)</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.13 22-03-2022. Adding Ethereum & Solana</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.14 09-08-2022. Adding Polkadot, Cardano, Avalanche</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.15 28-03-2023. Adding Tezos, Monero, updating script: updating encryption of requests/responses between our server & the client</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.16 13-08-2023. Decentralize the app (sharing the mnemonic phrase with the user & add compatibility with other wallets like trustwallet, metamask...), making email not required</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.17 15-08-2023. Add DDos protection (it may affect site loading)</p>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.18 30-08-2023. Fix monero issues, add qr to other crypto currencies (was with btc only), add click to copy address</p>
         <p style="text-align: center;font-size: 18px;line-height: 1.5;">V 1.19 08-10-2023. Update UI, add mobile support, correct server side validation (the issue is the price may change at the moment of transaction validation cause unseccessfull transaction, but now we attache the rate on the moment when user purchase something)</p>
    </div>
</body>
<footer>
     <script>
        (function($){
            if( $(window).width() <= 1000 ){
                $('#greeting, #container, #api').css('width','90%');
                //$('#ip').css('width','100%');
                $('#container').css('margin-top','100px');
                //$('#uploader').css('margin-top','-50px');
                //$('#clicktoupload').css('top','200px');
            }
        
        })(jQuery);
    </script>
</footer>
</html>





