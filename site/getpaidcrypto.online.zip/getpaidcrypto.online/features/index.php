<?php

?>
<!doctype html>
<html style="background-color:white;font-family: Arial;">
<head  >
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.png" />
	<script type="text/javascript" src="/jquery.min.js"></script>
	 <title>Crypto | Features</title>
</head>
<body style="background-color:white;font-family: Arial;" >
    <div id="greeting" style="position: relative;width: 90%;margin-right:auto;margin-left:auto;margin-top:80px">
        <ul style="text-align: center"><h1>Below, why GetPaidCryptoOnline is important</h1>
        <li style="text-align: center;font-size: 18px;line-height: 1.5;">Quick start: no signup required, no ID verification required, no email required, almost 5 min to fully integrate our crypto payments button</li>
        <li style="text-align: center;font-size: 18px;line-height: 1.5;">Decentralized: we share with you the mnemonic phrase of your wallet, manage your revenues whereever you want</li>
        <li style="text-align: center;font-size: 18px;line-height: 1.5;">Universal: target any client who has crypto wallet, not only clients on such crypto platform</li>
        <li style="text-align: center;font-size: 18px;line-height: 1.5;">Secure/Safe: we've DDos protection, we approve only transaction marked as success / exceed certain number of confirmations, we also block side/parallel trasactions comes from hackers that listen on the merchant address for incoming transaction</li>
        <li style="text-align: center;font-size: 18px;line-height: 1.5;">Multilingual: languages supported are: ar, bn, zh, cs, en, da, nl, fr, de, he, hi, id, it, ja, ko, pl, pt, ru, sv, es, tr, uk, vi</li>
        <li style="text-align: center;font-size: 18px;line-height: 1.5;">Responsive</li>
        </ul>
    </div>
</body>
<footer>
     <script>
        (function($){
            if( $(window).width() <= 1000 ){
                $('#greeting, #container, #api').css('width','90%');
                //$('#ip').css('width','100%');
                $('#container').css('margin-top','100px');
                //$('#uploader').css('margin-top','-50px');
                //$('#clicktoupload').css('top','200px');
            }
        
        })(jQuery);
    </script>
</footer>
</html>





