<?php

?>
<!doctype html>
<html style="background-color:white;font-family: Arial;">
<head  >
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.png" />
	<script type="text/javascript" src="/jquery.min.js"></script>
	 <title>Crypto | Fees</title>
</head>
<body style="background-color:white;font-family: Arial;" >
    <div id="greeting" style="position: relative;width: 90%;margin-right:auto;margin-left:auto;margin-top:80px">
         <h1 style="text-align: center">Unique fee (on receiving)</h1>
        <ul style="text-align: left;font-size:17px;line-height:1.5">Depending on the product/service price:
        <li>Micropayments, under or equal to 10$: our fee is 20%</li>
        <li>Between 10 & 100$ (or equal to 100$): our fee is 1$ (fixed)</li>
        <li>More than 100$: our fee is 1.5%</li>
        </ul><br/>
        
        <h1 style="text-align: center">What are transaction fees?</h1>
        
        <p style="text-align: left;font-size:17px;line-height:1.5">Depending of network you use, for the information, the standard fees per standard transaction are summarized in next table:</p><br/>
        <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
        <table>
  <tr>
    <th>Network</th>
    <th>Fee</th>
    <th>Pratical Fee</th>
  </tr>
  <tr>
    <td>Bitcoin</td>
    <td>min(required): <400 satoshis, recommanded: 2000 satoshis, works: 1000 satoshis</td>
    <td>0.00002 BTC</td>
  </tr>
  <tr>
    <td>Ethereum</td>
    <td>21310 wgei</td>
    <td>0.00003507 ETH</td>
  </tr>
  <tr>
    <td>Solana</td>
    <td>5000 lamports</td>
    <td>0.000005 SOL</td>
  </tr>
  <tr>
    <td>Avalanche</td>
    <td>maxfeepergas + 25 gwei</td>
    <td>Between 0.005 AVAX & 0.0005 AVAX</td>
  </tr>
  <tr>
    <td>Polkadot</td>
    <td>partialfee</td>
    <td>0.018 DOT</td>
  </tr>
  <tr>
    <td>Cardano</td>
    <td>minfee</td>
    <td>0.2 ADA</td>
  </tr>
</table><br/>
<p style="text-align: left;font-size:17px;line-height:1.5">So before send a transaction try to minus the network fee from the amount</p><br/>
        
    </div>
</body>
<footer>
     <script>
        (function($){
            if( $(window).width() <= 1000 ){
                $('#greeting, #container, #api').css('width','90%');
                //$('#ip').css('width','100%');
                $('#container').css('margin-top','100px');
                //$('#uploader').css('margin-top','-50px');
                //$('#clicktoupload').css('top','200px');
            }
        
        })(jQuery);
    </script>
</footer>
</html>





