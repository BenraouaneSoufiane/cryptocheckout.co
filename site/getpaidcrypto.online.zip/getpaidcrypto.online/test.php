<?php


    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,'https://ocr.hirak.site/');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'photo='.base64_encode(file_get_contents('C:\Apache24\htdocs\crypto.hirak.site\Capture d’écran 2022-07-15 181555.png')).'&type=png&lang=eng');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $server_output = curl_exec($ch);
    curl_close($ch);

print_r(base64_encode(file_get_contents('C:\Apache24\htdocs\crypto.hirak.site\test0.png')));