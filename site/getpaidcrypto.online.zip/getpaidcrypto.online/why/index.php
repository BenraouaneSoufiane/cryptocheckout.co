<?php

?>
<!doctype html>
<html style="background-color:#bff4ed;font-family: Arial;">
<head  >
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.png" />
	<script type="text/javascript" src="/jquery.min.js"></script>
	 <title>Crypto | Why email is required on generating crypto addresses?</title>
</head>
<body style="background-color:#bff4ed;font-family: Arial;" >
    <div id="greeting" style="position: relative;width: 55%;margin-right:auto;margin-left:auto;margin-top:80px">
        <h1 style="text-align: center">Why email is required on generating crypto addresses?</h1>
        <p style="text-align: left;font-size:17px;line-height:1.5">We use it as <a href="https://www.google.com/search?client=firefox-b-d&q=OTP" target="_blank">OTP</a> (One Time Password an automatically generated numeric or alphanumeric string of characters that authenticates a user for a single transaction or login session) to ensure the response from our server to you is only see by you, not any other party (ISP....), the response includes the private keys of your crypto addresses & associated account charcter's phrase used to doing transactions in this site without providing your crypto address even private key</p><br/>
        
    </div>
</body>
<footer>
     <script>
        (function($){
            if( $(window).width() <= 1000 ){
                $('#greeting, #container, #api').css('width','90%');
                //$('#ip').css('width','100%');
                $('#container').css('margin-top','100px');
                //$('#uploader').css('margin-top','-50px');
                //$('#clicktoupload').css('top','200px');
            }
        
        })(jQuery);
    </script>
</footer>
</html>





