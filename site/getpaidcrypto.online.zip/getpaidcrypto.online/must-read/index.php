<?php

?>
<!doctype html>
<html style="background-color:white;font-family: Arial;">
<head  >
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.png" />
	<script type="text/javascript" src="/jquery.min.js"></script>
	 <title>Crypto | Our Security Standards</title>
</head>
<body style="background-color:white;font-family: Arial;" >
    <div id="greeting" style="position: relative;width: 55%;margin-right:auto;margin-left:auto;margin-top:80px">
        <h1 style="text-align: center">Introduction</h1>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">This liteweight online tool allow you safely to accept crypto payments on your website quikly in three steps without sign up:</p><br/>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">1- Generating the wallet & retreive the mnemonic phrase & the ID.</p><br/>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">2- Integrate the tool/script replace the ID with your ID.</p><br/>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">3- Manage your wallet using crypto wallets like trustwallet, metamask..., integration of this tool require coding basics, but you can do without it just copy-paste the code.</p><br/>
        
        <h1 style="text-align: center">Trnsaction validation procedure/flow</h1>
        
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">1- Creating transaction with its data (amount, type of crypto currency, six characters of payer address address, ip, timestamp, cookie..) when user type the six chartcters of his address, marking it as pending, retreiving the transaction hash/ID, any other side/simultanous/parallele validations from other locations will ignored/blocked/discard (usally comes from spying on the merchant address on the blockchain explorers, & they try to simulate a payment process)</p><br/> 
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">2- Matching trancation amount & payed address with the received amount using the associated blochain explorer (this included also checking number of confirmation or status success depending on crypto currency type)</p><br/>             
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">3- If data matches, mark the transaction as completed, blacklist the transaction hash, send the local transaction hash/ID & the global transaction hash to the user</p><br/> 
        
    </div>
</body>
<footer>
     <script>
        (function($){
            if( $(window).width() <= 1000 ){
                $('#greeting, #container, #api').css('width','90%');
                //$('#ip').css('width','100%');
                $('#container').css('margin-top','100px');
                //$('#uploader').css('margin-top','-50px');
                //$('#clicktoupload').css('top','200px');
            }
        
        })(jQuery);
    </script>
</footer>
</html>





