<?php

declare(strict_types=1);

namespace phpseclib3\Net\SSH2;

/**
 * @internal
 */
abstract class TerminalMode
{
    public const TTY_OP_END = 0;
}
