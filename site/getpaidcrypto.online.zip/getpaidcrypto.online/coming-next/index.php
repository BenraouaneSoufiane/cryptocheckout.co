<?php

?>
<!doctype html>
<html style="background-color:white;font-family: Arial;">
<head  >
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon.png" />
	<script type="text/javascript" src="/jquery.min.js"></script>
	 <title>Crypto | Our Security Standards</title>
</head>
<body style="background-color:white;font-family: Arial;" >
    <div id="greeting" style="position: relative;width: 55%;margin-right:auto;margin-left:auto;margin-top:80px">
        <h1 style="text-align: center">Coming Next</h1>
        <p style="text-align: center;font-size: 18px;line-height: 1.5;">We're working to add other crypto currencies: dash, litecoin, digibyte, uniswap, 1inche, bnb..... , adding reactjs, next.js & nest.js support, making this tool available on e-commerce platforms/providers like woocommerce, shopify, magento, whm, wix, webflow, bigcommerce...., add live chat...</p><br/>     
         
        
    </div>
</body>
<footer>
     <script>
        (function($){
            if( $(window).width() <= 1000 ){
                $('#greeting, #container, #api').css('width','90%');
                //$('#ip').css('width','100%');
                $('#container').css('margin-top','100px');
                //$('#uploader').css('margin-top','-50px');
                //$('#clicktoupload').css('top','200px');
            }
        
        })(jQuery);
    </script>
</footer>
</html>





