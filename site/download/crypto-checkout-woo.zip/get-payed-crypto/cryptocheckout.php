<?php
/*
 * Plugin Name: Crypto Checkout for Woocommerce
 * Plugin URI: https://getpaidcrypto.online/
 * Description: Accept crypto payments on your Woocommerce store.
 * Author: Getpaidcrypto.online
 * Author URI: https://getpaidcrypto.online
 * Version: 1.0.5
 */


/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter( 'woocommerce_payment_gateways', 'gpcrypto_add_gateway_class' );
function gpcrypto_add_gateway_class( $gateways ) {
    $gateways[] = 'WC_GPC_Gateway'; // your class name is here
    return $gateways;
}

/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action( 'plugins_loaded', 'gpcrypto_init_gateway_class' );
function gpcrypto_init_gateway_class() {
    if(class_exists('WC_Payment_Gateway')){
        class WC_GPC_Gateway extends WC_Payment_Gateway {

            /**
             * Class constructor, more about it in Step 3
             */
            public function __construct() {    

                $this->id = 'ccp'; // payment gateway plugin ID
                $this->icon = ''; // URL of the icon that will be displayed on checkout page near your gateway name
                $this->has_fields = true; // in case you need a custom credit card form
                $this->method_title = 'Crypto currencies';
                $this->method_description = 'Accept crypto payements on your store'; // will be displayed on the options page    

                // gateways can support subscriptions, refunds, saved payment methods,
                // but in this tutorial we begin with simple payments
                $this->supports = array(
                    'products'
                );    

                // Method with all the options fields
                $this->init_form_fields();    

                // Load the settings.
                $this->init_settings();
                $this->title = $this->get_option( 'title' );
                $this->description = $this->get_option( 'description' );
                $this->enabled = $this->get_option( 'enabled' );
                $this->mid = $this->get_option( 'mid' );
                $this->lang = $this->get_option( 'lang' );
                $this->btc = $this->get_option('btc');
                $this->eth = $this->get_option('eth');
                $this->sol = $this->get_option('sol');
                $this->avax = $this->get_option('avax');
                $this->dot = $this->get_option('dot');
                $this->ada = $this->get_option('ada');
                $this->xtz = $this->get_option('xtz');
                $this->xmr = $this->get_option('xmr');
                $this->btcprice = $this->get_option('btcprice');
                $this->ethprice = $this->get_option('ethprice');
                $this->solprice = $this->get_option('solprice');
                $this->avaxprice = $this->get_option('avaxprice');
                $this->dotprice = $this->get_option('dotprice');
                $this->adaprice = $this->get_option('adaprice');
                $this->xtzprice = $this->get_option('xtzprice');
                $this->xmrprice = $this->get_option('xmrprice');
                $this->prices = $this->get_option('prices');
                $this->transactions = $this->get_option('transactions');
                // This action hook saves the settings
                add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
                //add_action( 'woocommerce_thankyou', array( $this, 'process_payments' ));    

                // We need custom JavaScript to obtain a token
                add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
                add_action( 'admin_print_scripts-woocommerce_page_wc-settings', array( $this, 'print_helper_script' ) );
            }    

            /**
             * Plugin options, we deal with it in Step 3 too
             */
            public function init_form_fields(){    

                $this->form_fields = array(
                    'enabled' => array(
                        'title'       => 'Enable/Disable',
                        'label'       => 'Enable Crypto Checkout',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'no'
                    ),
                    'title' => array(
                        'title'       => 'Title',
                        'type'        => 'text',
                        'description' => 'This controls the title which the user sees during checkout.',
                        'default'     => 'Pay using crypto currencies',
                        'desc_tip'    => true,
                    ),
                    'description' => array(
                        'title'       => 'Description',
                        'type'        => 'textarea',
                        'description' => 'This controls the description which the user sees during checkout.',
                        'default'     => 'Pay using your crypto funds via our super-cool payment gateway.',
                    ),
                    'mid' => array(
                        'title'       => 'ID',
                        'type'        => 'text',
                        'description' => 'Generate your wallet here: <a href="https://getpaidcrypto.online/" target="_blank">https://getpaidcrypto.online</a> & paste your ID',           
                    ),
                    'lang' => array(
                        'title'       => 'Language',
                        'type'        => 'text',
                        'description' => 'ISO 639‑1 language code (two charcters)',
                        'default'     => 'en',
                        'desc_tip'    => true
                    ),
                    'prices' => array(
                        'title'       => 'Prices',
                        'label'       => 'Market price',
                        'type'        => 'select',
                        'class'       => 'prices',                        
                        'options'     => array('market'=>'Market','isolated'=>'Isolated'),
                        'description' => 'Market or Isolated price',
                        'default'     => 'market'
                    ), 
                    'btc' => array(
                        'title'       => 'Bitcoin',
                        'label'       => 'Enable Bitcoin',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'eth' => array(
                        'title'       => 'Ethereum',
                        'label'       => 'Enable Ethereum',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'sol' => array(
                        'title'       => 'Solana',
                        'label'       => 'Enable Solana',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'avax' => array(
                        'title'       => 'Avalanche',
                        'label'       => 'Enable Avalanche',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'ada' => array(
                        'title'       => 'Cardano',
                        'label'       => 'Enable Cardano',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'dot' => array(
                        'title'       => 'Polkadot',
                        'label'       => 'Enable Polkadot',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'xtz' => array(
                        'title'       => 'Tezos',
                        'label'       => 'Enable Tezos',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ), 
                    'xmr' => array(
                        'title'       => 'Monero',
                        'label'       => 'Enable Monero',
                        'type'        => 'checkbox',
                        'description' => '',
                        'default'     => 'yes'
                    ),
                    'btcprice' => array(
                        'title'       => 'Bitcoin Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                    ),
                    'ethprice' => array(
                        'title'       => 'Ethereum Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    ),
                    'solprice' => array(
                        'title'       => 'Solana Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    ),
                    'avaxprice' => array(
                        'title'       => 'Avalanche Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    ),
                    'dotprice' => array(
                        'title'       => 'Polkadot Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    ),
                    'adaprice' => array(
                        'title'       => 'Cardano Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    ),
                    'xtzprice' => array(
                        'title'       => 'Tezos Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    ),
                    'xmrprice' => array(
                        'title'       => 'Monero Price',
                        'type'        => 'text',                        
                        'default'     => '',
                        'class'       => 'cprice',
                        'desc_tip'    => true,
                    )        
                );
            }    

            public function print_helper_script(){
                ?>
                <script src='/wp-includes/js/jquery/jquery.min.js'></script>
                <script>
                    (function($){
                        $(document).ready(function(){
                            $('.prices').val("<?php echo wp_kses_post($this->get_option('prices')) ?>");
                            $('.prices').on('change',function(){
                                //$(this).val(($(this).val()));
                                if($(this).val()=='market'){
                                    $('label[for="woocommerce_ccp_btcprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_ethprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_solprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_avaxprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_dotprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_adaprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_xtzprice"]').parent().parent().hide();
                                    $('label[for="woocommerce_ccp_xmrprice"]').parent().parent().hide();
                                }else{
                                    $('label[for="woocommerce_ccp_btcprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_ethprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_solprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_avaxprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_dotprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_adaprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_xtzprice"]').parent().parent().show();
                                    $('label[for="woocommerce_ccp_xmrprice"]').parent().parent().show();
                                    alert('Now you must setup values below')
                                }
                                
                            })
                            if("<?php echo wp_kses_post($this->get_option('prices')) ?>"=="market"){           
                                $('label[for="woocommerce_ccp_btcprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_ethprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_solprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_avaxprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_dotprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_adaprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_xtzprice"]').parent().parent().hide();
                                $('label[for="woocommerce_ccp_xmrprice"]').parent().parent().hide();
                            }

                        })                        
                    })(jQuery)
                </script>
                <?php
            }
         
            /**
             * You will need it if you want your custom credit card form, Step 4 is about it
             */
            public function payment_fields() { 
                global $woocommerce;   
                $r = json_decode(wp_remote_get('https://rates.translatewp.online/rate.php?from='.get_option('woocommerce_currency').'&to=USD&token=6fd8404714f243391d3f125910b4338a')['body'])->rate;        
                if( $this->prices ==='market' ){             
                    ?>
                    <script>;
                        (function($){                
                            showbtn("payment_method_ccp",{usd: <?php echo (float)($woocommerce->cart->total*$r) ?>}, onApprove = function(transactionId){
                                    (function($){                                    
                                        $.post('http://'+window.location.hostname+'/?wc-ajax=checkout',$('.checkout').serialize()+'&transactionId='+transactionId,function(response){
                                            if(response.result == 'success'){
                                                if(response.download_urls !== ''){
                                                    $.each(response.download_urls,function(i,j){
                                                        window.open(j,'_blank');
                                                    })                                            
                                                }                                        
                                                console.log(response);
                                                window.location.assign(response.redirect);
                                            }else{
                                                alert(response.message);
                                            }                                        
                                        })
                                    })(jQuery)},onError = function(error){
                                    (function($){
                                        alert(error)
                                    })(jQuery)}
                            )
                        })(jQuery)
                    </script>
                    <?php
                    
                }else{                
                   $prices = array();
                   if($this->btc === 'yes' && $this->btcprice !=='' ){
                       $prices['btc']=round(floatval($this->btcprice)*floatval($woocommerce->cart->total*$r),6);  
                   }
                   if($this->eth === 'yes' && $this->ethprice !=='' ){
                       $prices['eth']=round(floatval($this->ethprice)*floatval($woocommerce->cart->total*$r),6);  
                   }
                   if($this->sol === 'yes' && $this->solprice !=='' ){
                       $prices['sol']=round(floatval($this->solprice)*floatval($woocommerce->cart->total*$r),6);  
                   }
                   if($this->dot === 'yes' && $this->dotprice !=='' ){
                       $prices['dot']=round(floatval($this->dotprice)*floatval($woocommerce->cart->total*$r),6);  
                   }
                   if($this->avax === 'yes' && $this->avaxprice !=='' ){
                       $prices['avax']=round(floatval($this->avaxprice)*floatval($woocommerce->cart->total*$r),6); 
                   }
                   if($this->xtz === 'yes' && $this->xtzprice !=='' ){
                       $prices['xtz']=round(floatval($this->xtzprice)*floatval($woocommerce->cart->total*$r),6);  
                   }
                   if($this->xmr === 'yes' && $this->xmrprice !=='' ){
                       $prices['xmr']=round(floatval($this->xmrprice)*floatval($woocommerce->cart->total*$r),6);  
                   }
                   if($this->ada === 'yes' && $this->adaprice !=='' ){
                       $prices['ada']=round(floatval($this->adaprice)*floatval($woocommerce->cart->total*$r),6);  
                   }    

                   ?>               
                   <script>
                        (function($){    

                            showbtn("payment_method_ccp",<?php echo wp_kses_post(json_encode($prices)) ?>, onApprove = function(transactionId){
                                    (function($){    

                                        $.post('http://'+window.location.hostname+'/?wc-ajax=checkout',$('.checkout').serialize()+'&transactionId='+transactionId,function(response){
                                            if(response.result == 'success'){
                                                if(response.download_urls !== ''){
                                                    $.each(response.download_urls,function(i,j){
                                                        window.open(j,'_blank');
                                                    })
                                                }
                                                console.log(response);
                                                window.location.assign(response.redirect);
                                            }else{
                                                alert(response.message);
                                            }
                                            
                                            
                                        })
                                    })(jQuery)},onError = function(error){
                                    (function($){
                                        alert(error);
                                    })(jQuery)}
                            );
                        })(jQuery)
                    </script>
                    <?php
                    
                                                  
                }                 
            }    

            /*
             * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
             */
            public function payment_scripts() {
                
                // we need JavaScript to process a token only on cart/checkout pages, right?
                if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {
                    return;
                }    

                // if our payment gateway is disabled, we do not have to enqueue JS too
                if ( 'no' === $this->enabled ) {
                    return;
                }    

                // no reason to enqueue JavaScript if API keys are not set
                if ( empty( $this->mid ) || empty( $this->lang ) ) {
                    return;
                }    

                // do not work with card detailes without SSL unless your website is in a test mode
                /*if ( ! is_ssl() ) {
                    return;
                }*/    

                $curr = array();
                if($this->btc === 'yes' ){
                    $curr[]='btc';
                }
                if($this->eth === 'yes' ){
                    $curr[]='eth';
                }
                if($this->sol === 'yes' ){
                    $curr[]='sol';
                }
                if($this->ada === 'yes' ){
                    $curr[]='ada';
                }
                if($this->dot === 'yes' ){
                    $curr[]='dot';
                }
                if($this->avax === 'yes' ){
                    $curr[]='avax';
                }
                if($this->xtz === 'yes' ){
                    $curr[]='xtz';
                }
                if($this->xmr === 'yes' ){
                    $curr[]='xmr';
                }
        
                wp_enqueue_script( 'gpc_script', 'https://getpaidcrypto.online/crypto-woo.js?id='.$this->mid.'&lang='.$this->lang.'&curr='.implode('+',$curr) );
                          
                
            }
            public function process_payment($order_id){            
                global $woocommerce;
                    $pds = $woocommerce->cart->get_cart();
                    $total = 0;
                    $download_urls = array();
                    foreach($pds as $p => $v ){
                        $product = wc_get_product($v['product_id']);
                        $downloads = $product->get_downloads();
                        foreach( $downloads as $key => $each_download ) {
                            $download_urls[] = $each_download["file"];
                        }                    
                        $total += get_post_meta($v['product_id'] , '_price', true)*$v['quantity'];
                    }
                    $r = json_decode(wp_remote_get('https://rates.translatewp.online/rate.php?from='.get_option('woocommerce_currency').'&to=USD&token=6fd8404714f243391d3f125910b4338a')['body'])->rate;
                    $total = $total*floatval($r);
                    if( $this->prices === 'market' ){                  
                        $r1 = json_decode(wp_remote_get('https://getpaidcrypto.online/?transaction='.sanitize_text_field($_POST['transactionId']))['body']); 
                        $r = json_decode(wp_remote_get('https://rates.translatewp.online/rate.php?from=USD&to='.$r1->curr.'&token=6fd8404714f243391d3f125910b4338a')['body'])->rate;
                                       
                        if( $r1->completed == true &&  abs(floatval($r1->amount) - ($total*floatval($r1->rate))) < 0.0000001 ){ 
                            $transactions = get_option('transactions');
                            if( empty($transactions) ){
                                $transactions = array();
                                $transactions[]=sanitize_text_field($_POST['transactionId']);
                                update_option('transactions',$transactions);
                                return $this->completeorder($order_id,$download_urls);
                                
                            }else{
                                foreach($transactions as $transaction => $hash){
                                    if( $hash == sanitize_text_field($_POST['transactionId']) ){
                                        $exist = true;
                                        break;
                                    }elseif($transaction==count($transactions)-1 && $exist == false){             
                                        $transactions[]=sanitize_text_field($_POST['transactionId']);
                                        update_option('transactions',$transactions);
                                        return $this->completeorder($order_id,$download_urls);
                                    }
                                }
                            }                       
                        }
                    }else{                    
                        $r1 = json_decode(wp_remote_get('https://getpaidcrypto.online/?transaction='.sanitize_text_field($_POST['transactionId']))['body']);                    
                        if( $r1->completed == true && abs(floatval($r1->amount) - floatval($this->unitfromamount($r1->curr,$total*$this->getprice($r1->curr)))) < 1000 ){ 
                            $transactions = get_option('transactions');
                            if( empty($transactions) ){
                                $transactions = array();
                                $transactions[]=sanitize_text_field($_POST['transactionId']);
                                update_option('transactions',$transactions);
                                return $this->completeorder($order_id,$download_urls);                            
                            }else{
                                foreach($transactions as $transaction => $hash){
                                    if( $hash == sanitize_text_field($_POST['transactionId']) ){
                                        $exist = true;
                                        break;
                                    }elseif($transaction==count($transactions)-1 && $exist == false){             
                                        $transactions[]=sanitize_text_field($_POST['transactionId']);
                                        update_option('transactions',$transactions);
                                        return $this->completeorder($order_id,$download_urls);
                                    }
                                }
                            }                       
                        }
                    }    

            }
            public function unitfromamount($coin,$amount){
                if($coin == 'btc'){
                    $decimal = 100000000;
                }elseif($coin=='eth' || $coin=='avax' ){
                    $decimal = 1000000000000000000;
                }elseif($coin=='sol' || $coin=='xmr'){
                    $decimal = 1000000000;
                }elseif($coin=='dot'){
                    $decimal = 1000000000000;
                }elseif($coin=='ada'){
                    $decimal = 1000000;
                }
                return $amount*$decimal;
            }
            public function getprice($coin){
                if($coin == 'btc'){
                    return $this->btcprice;
                }elseif($coin == 'eth'){
                    return $this->ethprice;
                }elseif($coin == 'sol'){
                    return $this->solprice;
                }elseif($coin == 'ada'){
                    return $this->adaprice;
                }elseif($coin == 'dot'){
                    return $this->dotprice;
                }elseif($coin == 'avax'){
                    return $this->avaxprice;
                }elseif($coin == 'xtz'){
                    return $this->xtzprice;
                }elseif($coin == 'xmr'){
                    return $this->xmrprice;
                }
            }
            public function completeorder($order_id,$download_urls){
                global $woocommerce;
                $order = wc_get_order($order_id);
                $order->payment_complete();
                $order->reduce_order_stock();
                $order->add_order_note( sanitize_text_field($_POST['order_comments']), true );
     
                // Empty cart
                $woocommerce->cart->empty_cart();
                return array(
                    'result' => 'success',
                    'redirect' => $this->get_return_url( $order ),
                    'download_urls' => $download_urls
                );
            }             
        }
    }    
}




register_activation_hook(__FILE__, 'gpcrypto_activation_notice');
function gpcrypto_activation_notice() {
    if(!class_exists('WC_Payment_Gateway')){
        $notices= get_option('gpcrypto_deferred_admin_notices', array());
        $notices[]= 'Crypto Checkout requires Woocommerce installed & activated';
        update_option('gpcrypto_deferred_admin_notices', $notices);
    }else{
        $notices= get_option('gpcrypto_deferred_admin_notices', array());
        $notices[]= 'Generate your wallet & get your ID here: <a href="https://getpaidcrypto.online" target="_blank">https://getpaidcrypto.online</a>';
        update_option('gpcrypto_deferred_admin_notices', $notices);
    }    
}


add_action('admin_notices', 'gpcrypto_admin_notices');
function gpcrypto_admin_notices() {
    if ($notices= get_option('gpcrypto_deferred_admin_notices')) {
        foreach ($notices as $notice) {
            echo "<div class='updated'><p>".wp_kses_post($notice)."</p></div>";
        }
        delete_option('gpcrypto_deferred_admin_notices');
    }
}

register_deactivation_hook(__FILE__, 'gpcrypto_deactivation');
function gpcrypto_deactivation() {
    delete_option('gpcrypto_version'); 
    delete_option('gpcrypto_deferred_admin_notices'); 
}