=== Crypto Checkout for Woocommerce ===
 
Contributors: heroo
Tags: woocommerce, payment gateway, payments, payment, checkout, ecommerce, e-commerce
Requires at least: 5.6
Tested up to: 6.3.1
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
  
Accept crypto currencies payments on your Woocommerce store. 

== Description ==
  
All in one Secure Decentralized crypto payments gateway for Woocommerce.
<ul>Features:
<li>Start in seconds: no signup required, no ID verification required, no email required (optional), generate wallet in one click (retreive your mnemonic phrase & merchant ID), paste your merchant ID, the crypto payments button will add once you save changes, manage your revenues on any crypto wallet like trustwallet, metamask,...(by importing your mnemonic phrase).</li>
<li>Universal: target any client who has crypto wallet not only clients on such platform.</li>
<li>Decentralized: we share with you the mnemonic phrase of your wallet..</li>
<li>Setup isolated prices: if you don't need to follow the market prices, so no need to update the prices of all the products</li></ul>
Crypto currencies supported are: BTC, ETH, SOL, AVAX, ADA, DOT, XTZ, XMR.
Languages supported: ar, bn, zh, cs, en, da, nl, fr, de, he, hi, id, it, ja, ko, pl, pt, ru, sv, es, tr, uk, vi (ISO 639‑1).
<ul>Unique fee (on receiving):
<li>Micropayments, <10 (or equal to 10): 20%</li>
<li>Between 10 & 100 (or equal to 100): 1$ fixed.</li>
<li>>100: 1.5%</li>
</ul>
Live preview: <a href="https://myawesome.shop/checkout" target="_blank">https://myawesome.shop/checkout</a>
  
== Installation ==
  
1. Upload the plugin folder to your /wp-content/plugins/ folder.
1. Go to the **Plugins** page and activate the plugin.
  
== Frequently Asked Questions ==
  
= How do I use this plugin? =
  
You will need to create/generate new wallet from our site (you will get addresses, mnemonic phrase & ID)
Paste your id in the ID input form inside the woocommerce get payed crypto payment settings, the payment button will add automatically after enable the gateway/payment method, the prices will set depending to you: market price or isolated
Manage your wallet by paste the mnemonic phrase on trust wallet or any other wallet
  
= How to uninstall the plugin? =
  
Simply deactivate and delete the plugin. 
  
== Screenshots ==
1. Pay Now button.
2. Selecting the desired currency.
3. Collecting the user address, it's used for confirmation process (We ignore other/side confirmations from other locations comes from hackers that listen to the merchant address).
4. Zoom/maximize the image to see click to copy address (it's hidden under the right arrow).
5. Validating transaction using crypto explorers.
6. Admin dashboard (listed on the woo's payment methods).
7. Admin dashboard (options main page).
8. Admin dashboard (suite of options).
9. Admin dashboard (market prices).
10. Admin dashboard (isolated prices).
11. Admin dashboard (isolated prices, setup values).
  
== Changelog ==
= 1.0.0 (2023-06-02) =
* Plugin released. 

= 1.0.1 (2023-06-19) =
* Fix stuck/block/ when activating without Woocommerce is activated
* Update plugin options, prices menu drop down instead checkbox

= 1.0.3 (2023-09-07) =
* Fix admin notices
* Add default values of language (en) & prices (market)

= 1.0.5 (2023-10-14) =
* Enhance transaction validation, the issue before the fix is the rate may change at the moment of validating the transaction that cause failing, but now we've attache the rate at the moment when the user pay to the transaction object, so the problem goes away