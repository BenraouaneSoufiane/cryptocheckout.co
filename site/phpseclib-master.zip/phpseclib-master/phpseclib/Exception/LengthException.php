<?php

declare(strict_types=1);

namespace phpseclib3\Exception;

class LengthException extends \LengthException implements ExceptionInterface
{
}
